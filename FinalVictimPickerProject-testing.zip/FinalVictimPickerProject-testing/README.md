Required / Most Important
Pick Button
Victim Absent Recorder
Volunteer Interface/Option (text field?  drop down?)
Timer
Adding Points/ Removing Points

Optional / Ideas
List of Victims to choose from:  Wheel?  Plinko?
Textfield to enter in names that get added to the Wheel or Plinko
Pictures to accompany names
Add person button
Removal Function
Get Out of Jail Free (Roll of a 20-sided die, on a 20, you are free, on a 1, you have to do 2?)
Adding Points / Removing Points
Who Wants to Be a Millionaire Options:  Phone a friend, 50/50, Class Poll
Double or Nothing
Question interface  Display questions.  
Leaderboard
Sound Effects
