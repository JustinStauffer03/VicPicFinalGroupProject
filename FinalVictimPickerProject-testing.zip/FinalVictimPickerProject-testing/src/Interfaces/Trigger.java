package Interfaces;

public interface Trigger {
    void execute();
}
