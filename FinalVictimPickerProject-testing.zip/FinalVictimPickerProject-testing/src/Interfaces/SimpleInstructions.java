package Interfaces;

public interface SimpleInstructions {
    void execute();
}
