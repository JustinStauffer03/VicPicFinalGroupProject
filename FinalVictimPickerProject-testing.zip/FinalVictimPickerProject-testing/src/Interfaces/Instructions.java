package Interfaces;

public interface Instructions<T> {
    void update(T component);
}
