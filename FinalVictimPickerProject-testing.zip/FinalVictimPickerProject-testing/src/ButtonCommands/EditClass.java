package ButtonCommands;

import Students.Victim;
import UIElements.Panels.PlayerPanel;

import javax.swing.*;
import java.util.ArrayList;

public class EditClass {


}
