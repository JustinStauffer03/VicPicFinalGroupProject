package UIElements.Colors;

import java.awt.*;

public record ColorScheme(Color main, Color select, Color action) {
}
