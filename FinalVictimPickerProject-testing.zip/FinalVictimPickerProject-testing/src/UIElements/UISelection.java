package UIElements;

public interface UISelection {
    String selectTheme();
}
