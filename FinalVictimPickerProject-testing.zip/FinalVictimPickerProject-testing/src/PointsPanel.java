import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

public class PointsPanel extends JPanel
{
    private int index;
    public PointsPanel(int index)
    {

    }


}
